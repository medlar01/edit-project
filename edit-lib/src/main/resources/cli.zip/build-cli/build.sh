#!/bin/bash
cd $1
pwd
npm run lib