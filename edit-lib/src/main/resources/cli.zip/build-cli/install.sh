#!/bin/bash
cd $1
pwd
npm install